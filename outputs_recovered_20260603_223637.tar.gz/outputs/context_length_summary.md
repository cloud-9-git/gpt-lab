# 가설 D context_length 비교 결과

생성 시각: `2026-06-03 22:36:24`

## 결과 표

| context_length | 결과 파일 | Final Val Loss | Best Val Loss | Final Train Loss | 시간 | Train batches/epoch |
| --- | --- | --- | --- | --- | --- | --- |
| pretrain_context64_results.json | 없음 | - | - | - | - | - |
| pretrain_context128_results.json | 없음 | - | - | - | - | - |

## 그래프

## 해석 기준

- `context_length 128`의 validation loss가 더 낮으면 긴 문맥이 도움이 됐다고 볼 수 있다.
- `context_length 128`의 시간이 훨씬 길고 loss 차이가 작으면 비용 대비 이득이 작다고 볼 수 있다.
- 두 실험은 tokenizer, vocab_size, emb_dim, n_heads, n_layers, batch_size, epochs를 같게 맞춰야 비교가 깔끔하다.
