# mini GPT 실험 결과 요약

생성 시각: `2026-06-03 22:36:18`

## 1. 진행 상태

| 항목 | 상태 |
| --- | --- |
| 사전 학습 결과 | 있음 |
| Checkpoint 미세 조정 | 있음 |
| 랜덤 초기화 미세 조정 | 있음 |
| 가설 A 비교 가능 여부 | 가능 |

## 2. 사전 학습 결과

| 마지막 step | Train loss | Validation loss |
| --- | --- | --- |
| 3930 | 5.6334 | 5.8143 |

### Epoch별 train loss

| Epoch | Train loss |
| --- | --- |
| 1 | 7.3578 |
| 2 | 7.0737 |
| 3 | 6.5095 |
| 4 | 6.1437 |
| 5 | 5.9313 |

![Pretraining loss](pretrain_loss.png)

## 3. 감성 분류 미세 조정 결과

| 실험 | 파일 | 최종 Val Acc | 최종 Val Loss | Test Acc | Test Loss | 시간 |
| --- | --- | --- | --- | --- | --- | --- |
| finetune_cache_smoke_results | finetune_cache_smoke_results.json | 50.00% | 0.6568 | 56.25% | 0.7389 | 82.8분 |
| 사전 학습 checkpoint | finetune_checkpoint_results.json | 82.56% | 0.3825 | 82.88% | 0.3802 | 82.8분 |
| 랜덤 초기화 | finetune_random_results.json | 82.92% | 0.3805 | 83.06% | 0.3792 | 82.8분 |

![Fine-tuning accuracy](finetune_accuracy.png)

![Fine-tuning loss](finetune_loss.png)

![Test metrics](finetune_test_metrics.png)

## 4. 다음에 할 일

- `outputs/finetune_random_results.json`이 아직 없다면 랜덤 초기화 실험을 실행한다.
- 랜덤 초기화 결과가 생기면 `python scripts/render_experiment_report.py`를 다시 실행한다.
- 발표에는 `finetune_test_metrics.png`, `finetune_accuracy.png`, `pretrain_loss.png`를 캡처하거나 삽입한다.
